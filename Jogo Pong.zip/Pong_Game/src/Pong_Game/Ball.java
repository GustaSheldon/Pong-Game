package Pong_Game;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;

public class Ball{
	
	public double x = 20;
	public double y = 20;
	public int width, height;
	
	public double dx,dy;
	public static double speed = 2;
	
	public int EnemyScore;
	public int PlayerScore;
	
	public static int contCol;
	public boolean podeCont = true;
	
	public Ball(int x, int y) {
		this.x = x;
		this.y = y;
		width = 7;
		height = 7;
		
		int angle = new Random().nextInt(30,60);
		
		dx = Math.cos(Math.toRadians(angle));
		dy = Math.sin(Math.toRadians(angle));
	}
	
	private void resetBall() {
	    // Reposiciona a bola no centro da tela
	    x = Game.WIDTH / 2;
	    y = Game.HEIGHT / 2;

	    // Define uma nova direção aleatória para a bola
	    int angle = new Random().nextInt(30, 60);
	    dx = Math.cos(Math.toRadians(angle));
	    dy = Math.sin(Math.toRadians(angle));

	    // Garante que a bola não está se movendo na direção oposta
	    if (dx < 0) {
	        dx *= -1;
	    }
	}
	
	public void tick() {
		
		if(y+(dy*speed) + height >= Game.HEIGHT) {
			dy*=-1;
		}else if(y+(dy*speed) < 0) {
			dy*=-1;
		}
		
		if(x < 0 ) {
			//Enemy point
			EnemyScore++;
			contCol = 0;
			speed = 2;
			Game.enemy.resetEnemy();
			resetBall();
		}else if(x >= Game.WIDTH) {
			//Player point
			PlayerScore++;
			contCol = 0;
			speed = 2;
			Game.enemy.resetEnemy();
			resetBall();
		}
		
		Rectangle bounds = new Rectangle((int)(x+(dx*speed)),(int)(y+(dy*speed)),width,height);
		
		Rectangle boundsPlayer = new Rectangle(Game.player.x,Game.player.y,Game.player.width,Game.player.height);
		Rectangle boundsEnemy = new Rectangle((int)Game.enemy.x,(int)Game.enemy.y,Game.enemy.width,Game.enemy.height);
		
		if(bounds.intersects(boundsPlayer)) {
			int angle = new Random().nextInt(30,60);
			dx = Math.cos(Math.toRadians(angle));
			dy = Math.sin(Math.toRadians(angle));
			podeCont = true;
			if(podeCont) {
				contCol++;
				if(contCol >= 15) {
					speed = speed+1;
					Enemy.enemyPrecision = Enemy.enemyPrecision+=0.3;
					contCol = 0;
				}
			}
			if(dx < 0) {
				dx*=-1;
			}
		}else if(bounds.intersects(boundsEnemy)) {
			int angle = new Random().nextInt(30,60);
			dx = Math.cos(Math.toRadians(angle));
			dy = Math.sin(Math.toRadians(angle));
			if(dx > 0) {
				dx*=-1;
			}
			podeCont = true;
			if(podeCont) {
				contCol++;
				if(contCol >= 15) {
					speed = speed+1;
					Enemy.enemyPrecision = Enemy.enemyPrecision+=0.3;
					contCol = 0;
				}
			}
		}
		
		x+=dx*speed;
		y+=dy*speed;
		
	}
	
	public void render(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillOval((int)x, (int)y, width, height);
//		g.fillRect((int)x, (int)y, width, height);
	}
	
}
