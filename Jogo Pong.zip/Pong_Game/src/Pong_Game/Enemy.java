package Pong_Game;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

public class Enemy {
	
	public static double x,y;
	public int width, height;
	
	public boolean up,down;
	public static int velocity;
	
	public static double enemyPrecision;
	
	public Enemy(int x, int y) {
		this.x = x;
		this.y = y;
		this.width = 5;
		this.height = 35;
		this.enemyPrecision = 0.10;
	}

	public void resetEnemy() {
		x = Game.WIDTH-20;
		y = 40;
	}
	
	public void movimentacaoManual() {
		if(up) {
			if(Ball.contCol >= 15) {
				velocity = (int)y-2;
			}else {
				velocity = (int)y--;
			}
		}else if(down) {
			if(Ball.contCol >= 15) {
				velocity = (int)y+2;
			}else {
				velocity = (int)y++;
			}
		}
	}
	
	public void tick() {
			y+= (Game.ball.y - y - 6) * enemyPrecision;
			if(y+height > Game.HEIGHT) {
				y = Game.HEIGHT - height;
			}else if(y < 0) {
				y = 0;
			}
	}
	
	public void render(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(new Color(0,0,0,180));
		g2.fillRect(0, 0, Game.WIDTH, Game.HEIGHT);
		g2.drawImage(Game.enemyImage[0],(int)x-15,(int)y,null);
		g.setColor(Color.red);
//		g.fillRect((int)x, (int)y, width, height);
	}
	
}
