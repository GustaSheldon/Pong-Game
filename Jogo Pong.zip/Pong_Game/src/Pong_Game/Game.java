package Pong_Game;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;

public class Game extends Canvas implements KeyListener, Runnable{
	
	//Window Variables
	public static int WIDTH = 240;
	public static int HEIGHT = 120;
	public static int SCALE = 6;
	
	public BufferedImage layer = new BufferedImage(WIDTH,HEIGHT,BufferedImage.TYPE_INT_RGB);
	
	//Menu:
	public static String gameState = "MENU";
	public Menu menu;
	
	//Dificuldades:
	public Dificulty dif;
	public static String difOption = "Fácil";
	
	private SpriteSheet sheet;
	public static BufferedImage[] playerImage;
	public static BufferedImage[] enemyImage;
	public static Player player;
	public static Enemy enemy;
	public static Ball ball;
	
	public static boolean multiPlayer = false;
	
	public Game() {
		this.setPreferredSize(new Dimension(WIDTH*SCALE,HEIGHT*SCALE));
		this.addKeyListener(this);
		sheet = new SpriteSheet("/Entidades.png");
		playerImage = new BufferedImage[1];
		playerImage[0] = sheet.getSprite(0, 0, 35, 30);
		enemyImage = new BufferedImage[1];
		enemyImage[0] = sheet.getSprite(35, 0, 35, 30);
		player = new Player(10,40);
		enemy = new Enemy(WIDTH-20, 40);
		ball = new Ball(100,HEIGHT/2 - 1);
		this.multiplayer();
		//Inicializando o Menu
		menu = new Menu();
		//Inicializando as dificuldades
		dif = new Dificulty();
	}
	
	public static void main(String[] args) {
		Game game = new Game();
		JFrame frame = new JFrame("Pong");
		//Proíbe o usuário de mudar o tamanho da janela
		frame.setResizable(false);
		//Fazer com que a aplicação seja interrompida quando fechada
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(game);
		frame.pack();
		//Faz com que a janela seja iniciada no centro da tela
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		
		new Thread(game).start();
	}
	
	public void tick() {
//		System.out.println(""+gameState);
		if(gameState == "GAME") {
			player.tick();
			enemy.tick();
			ball.tick();
		}else if(gameState == "MENU") {
			menu.tick();
		}else if(gameState == "DIFICULDADE") {
			dif.tick();
		}
	}
	
	public void multiplayer(){
		if (multiPlayer = true){
			enemy.movimentacaoManual();
		}
	}
	
	public void render() {
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null) {
			this.createBufferStrategy(3);
			return;
		}
		
		Graphics g = layer.getGraphics();
		g.setColor(Color.black);
		g.fillRect(0, 0, WIDTH, HEIGHT);
		
		if(gameState == "MENU") {
			menu.render(g);
			g = bs.getDrawGraphics();
			g.drawImage(layer, 0, 0, WIDTH*SCALE, HEIGHT*SCALE, null);
			bs.show();
		}else if(gameState == "DIFICULDADE") {
			dif.render(g);
			g = bs.getDrawGraphics();
			g.drawImage(layer, 0, 0, WIDTH*SCALE, HEIGHT*SCALE, null);
			bs.show();
		}else if(gameState == "GAME"){
		
		//Renderização das entidades
		enemy.render(g);
		player.render(g);
		ball.render(g);
		
		//Placar:
		//Player
		g.setFont(new Font("Arial", Font.BOLD, 15));
		g.setColor(Color.WHITE);
		g.drawString(""+ball.PlayerScore, 95, 15);
		
		//Inimigo
		g.setFont(new Font("Arial", Font.BOLD, 15));
		g.setColor(Color.WHITE);
		g.drawString(""+ball.EnemyScore, 130, 15);
		
		//Traço central:
		for (int i=115; i>0;i-=9) {
			g.setColor(Color.WHITE);
			g.drawLine(WIDTH/2, i, WIDTH/2, i-3);
		}
		
		g = bs.getDrawGraphics();
		g.drawImage(layer, 0, 0, WIDTH*SCALE, HEIGHT*SCALE, null);
		}
		
		bs.show();
	}

	public void run() {
		while(true) {
			this.multiplayer();
			requestFocus();
			tick();
			render();
			try {
				Thread.sleep(1000/60);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void keyPressed(KeyEvent e) {
		if(gameState.equals("MENU")) {
			if(e.getKeyCode() == KeyEvent.VK_UP) {
				menu.up = true;
			}else if(e.getKeyCode() == KeyEvent.VK_DOWN) {
				menu.down = true;
			}else if(e.getKeyCode() == KeyEvent.VK_ENTER) {
				menu.ok = true;
			}
		}else if(gameState == "DIFICULDADE") {
			if(e.getKeyCode() == KeyEvent.VK_UP) {
				dif.cima = true;
			}else if(e.getKeyCode() == KeyEvent.VK_DOWN) {
				dif.baixo = true;
			}else if(e.getKeyCode() == KeyEvent.VK_ENTER) {
				dif.enter = true;
			}
		}else {
			if(e.getKeyCode() == KeyEvent.VK_UP) {
				player.up = true;
			}else if(e.getKeyCode() == KeyEvent.VK_DOWN) {
				player.down = true;
			}
			if(e.getKeyCode() == KeyEvent.VK_2) {
				multiPlayer = true;
				System.out.println("Multiplayer");
			}
		}
	}
	
	public void keyReleased(KeyEvent e) {
		if(gameState.equals("MENU")) {
			if(e.getKeyCode() == KeyEvent.VK_UP) {
				menu.up = false;
			}else if(e.getKeyCode() == KeyEvent.VK_DOWN) {
				menu.down = false;
			}else if(e.getKeyCode() == KeyEvent.VK_ENTER) {
				menu.ok = false;
			}
		}else if(gameState == "DIFICULDADE") {
			if(e.getKeyCode() == KeyEvent.VK_UP) {
				dif.cima = false;
			}else if(e.getKeyCode() == KeyEvent.VK_DOWN) {
				dif.baixo = false;
			}else if(e.getKeyCode() == KeyEvent.VK_ENTER) {
				dif.enter = false;
			}
		}
		else {
			if(e.getKeyCode() == KeyEvent.VK_UP) {
				player.up = false;
			}else if(e.getKeyCode() == KeyEvent.VK_DOWN) {
				player.down = false;
			}
		}
	}
	
	public void keyTyped(KeyEvent e) {
		
	}
	
}
