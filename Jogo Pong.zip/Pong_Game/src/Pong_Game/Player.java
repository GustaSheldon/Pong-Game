package Pong_Game;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

public class Player {
	
	public boolean up,down;
	
	public static int velocity;
	public int x,y;
	
	public int width, height;
	
	public Player(int x, int y) {
		this.x = x;
		this.y = y;
		this.width = 5;
		this.height = 35;
	}
	
	public void tick() {
		if(up) {
			if(Ball.contCol >= 15) {
				velocity = y-=2;
			}else {
				velocity = y--;
			}
		}else if(down) {
			if(Ball.contCol >= 15) {
				velocity = y+=2;
			}else {
				velocity = y++;
			}
		}
		
		if(y+height > Game.HEIGHT) {
			y = Game.HEIGHT - height;
		}else if(y < 0) {
			y = 0;
		}
	}
	
	public void render(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(new Color(0,0,0,180));
		g2.fillRect(0, 0, Game.WIDTH, Game.HEIGHT);
		g2.drawImage(Game.playerImage[0],x-15,y,null);
	}
	
}
