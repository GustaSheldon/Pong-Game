package Pong_Game;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Dificulty {
	
	public String[] options = {"Fácil, Médio, Difícil, Voltar"};
	public  int curOption = 0;
	public int maxOption = 3;
	
	public static boolean cima, baixo, enter;
	
	public static BufferedImage seta;
	private SpriteSheet sheet;
	
	public Dificulty() {
		sheet = new SpriteSheet("/Seta.png");
		seta = sheet.getSprite(0, 0, 16, 16);
	}
	
	public void tick() {
		System.out.println(""+curOption);
		if(baixo) {
			curOption++;
			baixo = false;
			if(curOption > maxOption) {
				curOption = 0;
			}
		}else if (cima) {
			curOption--;
			cima = false;
			if(curOption < 0) {
				curOption = maxOption;
			}
		}else if(enter) {
			if(curOption == 0) {
				//Dif Easy
				
			}else if(curOption == 1) {
				//Dif Medium
				
			}else if(curOption == 2) {
				//Dif Hard
				
			}else if(curOption == 3) {
				//Main Menu
				Game.gameState = "MENU";
			}
		}
	}

	public void render(Graphics g) {
		g.setColor(Color.black);
		g.fillRect(0, 0, Game.WIDTH*Game.SCALE, Game.HEIGHT*Game.SCALE);
		
		g.setFont(new Font("Arial", Font.BOLD, 10));
		g.setColor(Color.white);
		g.drawString("FÁCIL", Game.WIDTH/2-15, 45);
		g.drawString("MÉDIO", Game.WIDTH/2-18, 60);
		g.drawString("DIFÍCIL", Game.WIDTH/2-18, 75);
		g.drawString("VOLTAR", Game.WIDTH/2-18, 90);
	}
	
}
