package Pong_Game;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class Menu {

	public String[] options = {"Jogar", "Dificuldade", "Sair"};
	public static int currentOption = 0;
	public int maxOption = options.length - 1;
	
	public static boolean up, down, ok;
	
	public static BufferedImage seta;
	private SpriteSheet sheet;
	
	public Menu() {
		sheet = new SpriteSheet("/Seta.png");
		seta = sheet.getSprite(0, 0, 16, 16);
	}
	
	public void tick() {
		System.out.println(""+currentOption);
		if(down) {
			currentOption++;
			down = false;
			if(currentOption > maxOption) {
				currentOption = 0;
			}
		}else if(up) {
			currentOption--;
			up = false;
			if(currentOption < 0) {
				currentOption = maxOption;
			}
		}else if(ok) {
			ok = true;
			if(currentOption == 0) {
				//Inicia o jogo
				Game.gameState = "GAME";
			}else if(currentOption == 1) {
				//Escolher dificuldade
				Game.gameState = "DIFICULDADE";
			}else if(currentOption == 2) {
				//Fecha o jogo
				System.exit(0);
			}
		}
	}
	
	public static void render(Graphics g) {
		g.setColor(new Color(150,0,0));
		g.fillRect(0, 0, Game.WIDTH*Game.SCALE, Game.HEIGHT*Game.SCALE);
		
		g.setFont(new Font("Arial", Font.BOLD, 15));
		g.setColor(Color.white);
		g.drawString("PONG GAME", Game.WIDTH/2-45, 20);
		g.setFont(new Font("Arial", Font.BOLD, 10));
		g.drawString("JOGAR", Game.WIDTH/2-20, 50);
		g.drawString("DIFICULDADE", Game.WIDTH/2-35, 65);
		g.drawString("SAIR", Game.WIDTH/2-15, 80);
		
		if(currentOption == 0) {
			g.drawImage(seta, Game.WIDTH/2-35, 37, null);
		}else if(currentOption == 1) {
			g.drawImage(seta, Game.WIDTH/2-50, 53, null);
		}else if(currentOption == 2) {
			g.drawImage(seta, Game.WIDTH/2-30, 68, null);
		}
	}
	
}
